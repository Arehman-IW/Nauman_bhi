from odoo import models, fields, api, _
import logging
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    document_category = fields.Many2one(comodel_name='hr.document.template', string='Employee Category')
    employee_typee = fields.Selection(related='document_category.name')

    paid_time_off = fields.Boolean(
        string='Paid Time Off',
        compute='_compute_paid_time_off',
        store=True,
        readonly=False,
    )

    paid_time_off_readonly = fields.Boolean(
        string='Paid Time Off Readonly',
        compute='_compute_paid_time_off_readonly',
    )
    holiday_eligibility = fields.Boolean(
        string='Holiday Eligibility',
        compute='_compute_holiday_eligibility',
        store=True,
        readonly=False,
    )

    holiday_eligibility_readonly = fields.Boolean(
        string='Holiday Eligibility Readonly',
        compute='_compute_holiday_eligibility_readonly',
    )

    @api.depends('document_category')
    def _compute_holiday_eligibility(self):
        """Set checkbox value based on document category."""
        for employee in self:
            if not employee.document_category:
                employee.holiday_eligibility = False
                continue

            category_name = employee.document_category.name

            # Set default value for US Employee (non-editable)
            if category_name == 'us_employee':
                employee.holiday_eligibility = True
            # For all other categories, keep existing value (editable)

    @api.depends('document_category')
    def _compute_holiday_eligibility_readonly(self):
        """Determine if field should be readonly."""
        for employee in self:
            if not employee.document_category:
                employee.holiday_eligibility_readonly = False
                continue

            category_name = employee.document_category.name

            # Readonly only for US Employee
            if category_name == 'us_employee':
                employee.holiday_eligibility_readonly = True
            else:
                employee.holiday_eligibility_readonly = False


    @api.depends('document_category')
    def _compute_paid_time_off(self):
        """Set checkbox value based on document category."""
        for employee in self:
            if not employee.document_category:
                employee.paid_time_off = False
                continue

            category_name = employee.document_category.name

            # Set default values for non-editable categories
            if category_name == 'us_employee':
                employee.paid_time_off = True
            elif category_name == 'overseas_contractor':
                employee.paid_time_off = True  # Changed to True
            elif category_name == 'independent_contractor_us':
                employee.paid_time_off = False
            # For editable categories (intern, staffing_employee, temp_to_hire), keep existing value

    @api.depends('document_category')
    def _compute_paid_time_off_readonly(self):
        """Determine if field should be readonly."""
        for employee in self:
            if not employee.document_category:
                employee.paid_time_off_readonly = False
                continue

            category_name = employee.document_category.name

            # Readonly for these categories
            if category_name in ['us_employee', 'independent_contractor_us', 'overseas_contractor']:
                employee.paid_time_off_readonly = True
            else:
                employee.paid_time_off_readonly = False


    def write(self, vals):
        """Override write to upload documents when category is set or changed"""
        # Delete old documents if category is being changed
        if 'document_category' in vals:
            for employee in self:
                if employee.document_category:  # If there was a previous category
                    employee._delete_category_documents()

        result = super(HrEmployee, self).write(vals)

        # Only generate documents if document_category was changed and has a value
        if 'document_category' in vals and vals.get('document_category'):
            for employee in self:
                if employee.document_category:
                    employee.action_generate_documents_from_template()

        return result

    @api.model_create_multi
    def create(self, vals_list):
        """Auto-generate documents on employee creation if category is set."""
        employees = super(HrEmployee, self).create(vals_list)

        for employee in employees:
            if employee.document_category:
                employee.action_generate_documents_from_template()

        return employees

    def _delete_category_documents(self):
        """Delete all documents linked to this employee that were created from templates."""
        self.ensure_one()

        # Find all documents linked to this employee
        documents_to_delete = self.env['documents.document'].search([
            ('res_model', '=', 'hr.employee'),
            ('res_id', '=', self.id),
            ('partner_id', '=', self.work_contact_id.id),
        ])

        if documents_to_delete:
            _logger.info(
                f"Deleting {len(documents_to_delete)} document(s) for employee {self.name} before creating new ones")
            documents_to_delete.unlink()

    def action_generate_documents_from_template(self):
        """Generate documents from the selected template."""
        self.ensure_one()

        if not self.document_category:
            raise ValidationError(_('Please select a Document Category first.'))

        if not self.work_contact_id:
            raise ValidationError(_('Employee must have a contact linked.'))

        # Get all document lines from the template
        template_lines = self.document_category.document_ids

        if not template_lines:
            raise ValidationError(_('The selected template has no documents defined.'))

        created_documents = self.env['documents.document']

        for line in template_lines:
            # Skip if no file is uploaded in the template line
            if not line.document_file:
                continue

            # Prepare document values
            doc_vals = {
                'name': line.name or line.file_name or 'Untitled Document',
                'partner_id': self.work_contact_id.id,
                'res_model': 'hr.employee',
                'res_id': self.id,
                'datas': line.document_file,  # This is the actual file content
            }

            # Add folder if using modern approach
            if self.company_id.documents_hr_settings and self.hr_employee_folder_id:
                doc_vals['folder_id'] = self.hr_employee_folder_id.id
            elif line.folder_id:
                # Try to find folder by name if specified in template
                folder = self.env['documents.folder'].search([
                    ('name', '=', line.folder_id)
                ], limit=1)
                if folder:
                    doc_vals['folder_id'] = folder.id

            # Add tags if specified
            if line.tags:
                tag_names = [tag.strip() for tag in line.tags.split(',')]
                tags = self.env['documents.tag'].search([
                    ('name', 'in', tag_names)
                ])
                if tags:
                    doc_vals['tag_ids'] = [(6, 0, tags.ids)]

            # Create the document
            document = self.env['documents.document'].create(doc_vals)
            created_documents |= document

        # Show notification
        if created_documents:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Success'),
                    'message': _('%s document(s) created successfully.') % len(created_documents),
                    'type': 'success',
                    'sticky': False,
                }
            }
        else:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Warning'),
                    'message': _('No documents were created. Please check if template has files uploaded.'),
                    'type': 'warning',
                    'sticky': False,
                }
            }

    # @api.onchange('document_category')
    # def _onchange_document_category(self):
    #     """Optional: Show warning or info when category changes."""
    #     if self.document_category and self.document_category.document_ids:
    #         return {
    #             'warning': {
    #                 'title': _('Document Template Selected'),
    #                 'message': _(
    #                     'This template contains %s document(s). Documents will be generated automatically when you save.') % len(
    #                     self.document_category.document_ids)
    #             }
    #         }
    # def write(self, vals):
    #     """Override write to upload documents when category is set or changed"""
    #     result = super(HrEmployee, self).write(vals)
    #
    #     # Only generate documents if document_category was changed and has a value
    #     if 'document_category' in vals and vals.get('document_category'):
    #         for employee in self:
    #             if employee.document_category:
    #                 employee.action_generate_documents_from_template()
    #
    #     return result
    #
    # @api.model_create_multi
    # def create(self, vals_list):
    #     """Auto-generate documents on employee creation if category is set."""
    #     employees = super(HrEmployee, self).create(vals_list)
    #
    #     for employee in employees:
    #         if employee.document_category:
    #             employee.action_generate_documents_from_template()
    #
    #     return employees
    #
    # def action_generate_documents_from_template(self):
    #     """Generate documents from the selected template."""
    #     self.ensure_one()
    #
    #     if not self.document_category:
    #         raise ValidationError(_('Please select a Document Category first.'))
    #
    #     if not self.work_contact_id:
    #         raise ValidationError(_('Employee must have a contact linked.'))
    #
    #     # Get all document lines from the template
    #     template_lines = self.document_category.document_ids
    #
    #     if not template_lines:
    #         raise ValidationError(_('The selected template has no documents defined.'))
    #
    #     created_documents = self.env['documents.document']
    #
    #     for line in template_lines:
    #         # Skip if no file is uploaded in the template line
    #         if not line.document_file:
    #             continue
    #
    #         # Prepare document values
    #         doc_vals = {
    #             'name': line.name or line.file_name or 'Untitled Document',
    #             'partner_id': self.work_contact_id.id,
    #             'res_model': 'hr.employee',
    #             'res_id': self.id,
    #             'datas': line.document_file,  # This is the actual file content
    #         }
    #
    #         # Add folder if using modern approach
    #         if self.company_id.documents_hr_settings and self.hr_employee_folder_id:
    #             doc_vals['folder_id'] = self.hr_employee_folder_id.id
    #         elif line.folder_id:
    #             # Try to find folder by name if specified in template
    #             folder = self.env['documents.folder'].search([
    #                 ('name', '=', line.folder_id)
    #             ], limit=1)
    #             if folder:
    #                 doc_vals['folder_id'] = folder.id
    #
    #         # Add tags if specified
    #         if line.tags:
    #             tag_names = [tag.strip() for tag in line.tags.split(',')]
    #             tags = self.env['documents.tag'].search([
    #                 ('name', 'in', tag_names)
    #             ])
    #             if tags:
    #                 doc_vals['tag_ids'] = [(6, 0, tags.ids)]
    #
    #         # Create the document
    #         document = self.env['documents.document'].create(doc_vals)
    #         created_documents |= document
    #
    #     # Show notification
    #     if created_documents:
    #         return {
    #             'type': 'ir.actions.client',
    #             'tag': 'display_notification',
    #             'params': {
    #                 'title': _('Success'),
    #                 'message': _('%s document(s) created successfully.') % len(created_documents),
    #                 'type': 'success',
    #                 'sticky': False,
    #             }
    #         }
    #     else:
    #         return {
    #             'type': 'ir.actions.client',
    #             'tag': 'display_notification',
    #             'params': {
    #                 'title': _('Warning'),
    #                 'message': _('No documents were created. Please check if template has files uploaded.'),
    #                 'type': 'warning',
    #                 'sticky': False,
    #             }
    #         }
    #
    # @api.onchange('document_category')
    # def _onchange_document_category(self):
    #     """Optional: Show warning or info when category changes."""
    #     if self.document_category and self.document_category.document_ids:
    #         return {
    #             'warning': {
    #                 'title': _('Document Template Selected'),
    #                 'message': _(
    #                     'This template contains %s document(s). Documents will be generated automatically when you save.') % len(
    #                     self.document_category.document_ids)
    #             }
    #         }
    #
    # @api.model_create_multi
    # def create(self, vals_list):
    #     """Override create to upload documents for new employees with category"""
    #     employees = super(HrEmployee, self).create(vals_list)
    #
    #     for employee in employees:
    #         if employee.employee_category:
    #             _logger.info(f"New employee created with category: {employee.name} - {employee.employee_category}")
    #             employee._upload_category_documents()
    #
    #     return employees
    #
    # def _upload_category_documents(self):
    #     """Upload documents based on employee category"""
    #     self.ensure_one()
    #
    #     if not self.employee_category:
    #         _logger.warning(f"No employee category set for {self.name}")
    #         return 0
    #
    #     _logger.info(f"Starting document upload for {self.name} with category {self.employee_category}")
    #
    #     # Find document templates for this category
    #     templates = self.env['hr.document.template'].search([
    #         ('employee_category', '=', self.employee_category),
    #         ('active', '=', True)
    #     ])
    #
    #     _logger.info(f"Found {len(templates)} active template(s) for category {self.employee_category}")
    #
    #     if not templates:
    #         _logger.warning(f"No active templates found for category {self.employee_category}")
    #         return 0
    #
    #     # Check which document system is available
    #     has_documents_app = 'documents.document' in self.env
    #     has_hr_document = 'hr.document' in self.env
    #
    #     _logger.info(f"Document systems - Documents app: {has_documents_app}, HR Document: {has_hr_document}")
    #
    #     uploaded_count = 0
    #     for template in templates:
    #         _logger.info(f"Processing template: '{template.name}' with {len(template.document_ids)} document(s)")
    #
    #         for doc_line in template.document_ids:
    #             if not doc_line.document_file:
    #                 _logger.warning(f"Skipping '{doc_line.name}' - no file attached")
    #                 continue
    #
    #             try:
    #                 if has_documents_app:
    #                     self._create_documents_app_document(doc_line)
    #                     _logger.info(f"✓ Created document via Documents app: '{doc_line.name}'")
    #                 elif has_hr_document:
    #                     self._create_hr_document(doc_line)
    #                     _logger.info(f"✓ Created document via hr.document: '{doc_line.name}'")
    #                 else:
    #                     self._create_attachment_document(doc_line)
    #                     _logger.info(f"✓ Created document as attachment: '{doc_line.name}'")
    #
    #                 uploaded_count += 1
    #
    #             except Exception as e:
    #                 _logger.error(f"✗ Failed to upload '{doc_line.name}' for {self.name}: {str(e)}", exc_info=True)
    #
    #     _logger.info(f"Upload complete: {uploaded_count} document(s) uploaded for {self.name}")
    #     return uploaded_count
    #
    # def _create_documents_app_document(self, doc_line):
    #     """Create document using Documents app - Odoo 19 SAFE VERSION"""
    #     Documents = self.env['documents.document']
    #
    #     doc_vals = {
    #         'name': doc_line.name,
    #         'datas': doc_line.document_file,
    #         'res_model': 'hr.employee',
    #         'res_id': self.id,
    #         'owner_id': self.user_id.id if self.user_id else self.env.user.id,
    #     }
    #
    #     # --- FOLDER (only if model exists) ---
    #     if doc_line.folder_id and 'documents.folder' in self.env:
    #         folder = self.env['documents.folder'].search([('name', '=', doc_line.folder_id)], limit=1)
    #         if folder:
    #             doc_vals['folder_id'] = folder.id
    #             _logger.debug(f"Document folder applied: {folder.name}")
    #     else:
    #         _logger.debug("Folder ignored because 'documents.folder' model does not exist.")
    #
    #     # --- TAGS (safe, because documents.tag exists always) ---
    #     if doc_line.tags:
    #         tag_names = [tag.strip() for tag in doc_line.tags.split(',')]
    #         tags = self.env['documents.tag'].search([('name', 'in', tag_names)])
    #         if tags:
    #             doc_vals['tag_ids'] = [(6, 0, tags.ids)]
    #             _logger.debug(f"Tags applied: {tag_names}")
    #
    #     doc = Documents.create(doc_vals)
    #     _logger.info(f"Created document ID: {doc.id}")
    #     return doc
    #
    # def _create_hr_document(self, doc_line):
    #     """Create document using standard hr.document model"""
    #     HrDocument = self.env['hr.document']
    #
    #     doc_vals = {
    #         'name': doc_line.name,
    #         'datas': doc_line.document_file,
    #         'employee_id': self.id,
    #     }
    #
    #     doc = HrDocument.create(doc_vals)
    #     _logger.info(f"Created hr.document ID: {doc.id}")
    #     return doc
    #
    # def _create_attachment_document(self, doc_line):
    #     """Fallback: Create as ir.attachment"""
    #     Attachment = self.env['ir.attachment']
    #
    #     attachment_vals = {
    #         'name': doc_line.name,
    #         'datas': doc_line.document_file,
    #         'res_model': 'hr.employee',
    #         'res_id': self.id,
    #         'type': 'binary',
    #     }
    #
    #     attachment = Attachment.create(attachment_vals)
    #     _logger.info(f"Created attachment ID: {attachment.id}")
    #     return attachment