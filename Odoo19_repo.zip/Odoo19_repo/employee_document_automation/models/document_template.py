from odoo import models, fields, api


class DocumentTemplate(models.Model):
    _name = 'hr.document.template'
    _description = 'Employee Document Template'
    _rec_name = 'name'

    name = fields.Selection([
        ('us_employee', 'US Employee (W2)'),
        ('independent_contractor_us', 'Independent Contractor – US (1099)'),
        ('overseas_contractor', 'Overseas Independent Contractor'),
        ('staffing_employee', 'Staffing Employee'),
        ('intern', 'Intern'),
        ('temp_to_hire', 'Temp-to-Hire'),
    ], string='Template Name', required=True)

    document_ids = fields.One2many(
        'hr.document.template.line',
        'template_id',
        string='Documents'
    )

    active = fields.Boolean(default=True)


class DocumentTemplateLine(models.Model):
    _name = 'hr.document.template.line'
    _description = 'Document Template Line'

    template_id = fields.Many2one(
        'hr.document.template',
        string='Template',
        required=True,
        ondelete='cascade'
    )

    name = fields.Char(string='Document Name', required=True)

    document_file = fields.Binary(
        string='Upload File',
        required=False,
        attachment=True,
        help='Upload the document file (PDF, DOC, etc.)'
    )

    file_name = fields.Char(string='File Name')

    # Optional: Only if documents module is installed
    folder_id = fields.Char(
        string='Folder Name',
        help='Folder name where the document will be uploaded (if Documents app is installed)'
    )

    tags = fields.Char(
        string='Tags',
        help='Comma-separated tags to apply (if Documents app is installed)'
    )
    # type = fields.Selection(
    #     string='Document Type',
    #     selection=[
    #         ('employee_docs','employee docs'),
    #         ('policy','policy')
    #     ]
    # )